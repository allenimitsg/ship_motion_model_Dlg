#pragma once
#include <vector>
#include <functional>
#include <string>
#include <algorithm>
#include <iterator>
#include <cctype>
#include <fstream>
#include <sstream>

#include "afxsock.h"
//�޶���¼
//2012-02-29 ����SplitString ����delim���κ�һ���ַ������ɷָ��;ԭHaSplitString�����в���delim�������ַ������ɷָ��


// Get DLL instance
EXTERN_C IMAGE_DOS_HEADER __ImageBase;

namespace sgy
{
 	//////////////////////////////////////////////////////////////////
	//�ַ�������
	// 0   1   2   3   4   5   6   7   8   9   10
	// a , b , c , d , e , f , g , h , i , j ,  k
	//���ַ�������","�ָ�ɵ����д��ַ����ν��б��0,1,2...n
	///////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////
	//use std fully
	//dll style as following
	//AFX_API_EXPORT void HaSplitString(std::vector<CStringA>& vRlt,CStringA strOrg,char ctaken);

	inline std::string GetModulePath2()
	{
		std::string szText;
		HMODULE hModule = ::GetModuleHandleA(NULL);
		char lpFileName[260];
		memset(lpFileName,0,260*sizeof(char));
		::GetModuleFileNameA(hModule,lpFileName,260);
		std::string dir(lpFileName);
		//�ַ�����Сдת��
		std::transform(dir.begin(),dir.end(),dir.begin(),std::tolower);
		int i=0,len=dir.size();
		if(len<1) 
		{
			szText = "";
			return szText;
		}
		std::string::size_type pos=dir.find("\\debug\\");
		if(pos==std::string::npos) pos=dir.find("\\release\\");
		if(pos!=std::string::npos) 
		{
			szText = dir.substr(0,pos);
			return szText;
		}

		pos=dir.find_last_of('\\');
		if(pos!=std::string::npos) 
		{
			szText = dir.substr(0,pos);
			return szText;
		}
		szText = "";
		return szText;
	}

	inline std::string GetAnyModulePath2()
	{
		std::string szText;
		char lpFileName[260];
		memset(lpFileName,0,260*sizeof(char));
		::GetModuleFileNameA((HMODULE)&__ImageBase, lpFileName, 260);
		std::string dir(lpFileName);
		//�ַ�����Сдת��
		std::transform(dir.begin(),dir.end(),dir.begin(),std::tolower);
		int i=0,len=dir.size();
		if(len<1) 
		{
			szText = "";
			return szText;
		}
		std::string::size_type pos=dir.find("\\debug\\");
		if(pos==std::string::npos) pos=dir.find("\\release\\");
		if(pos!=std::string::npos) 
		{
			szText = dir.substr(0,pos);
			return szText;
		}

		pos=dir.find_last_of('\\');
		if(pos!=std::string::npos) 
		{
			szText = dir.substr(0,pos);
			return szText;
		}
		szText = "";
		return szText;
	}

	//�����༶Ŀ¼ SHCreateDirectoryEx creates a file system folder 
	//If one or more of the intermediate folders do not exist, they are created as well. 
	//SHCreateDirectoryEx also verifies that the files are visible.

	//ɾ���༶Ŀ¼ delete a directory and its subdirectories using the Shell API
	inline bool DeleteDirectory(LPCTSTR lpszDir, bool noRecycleBin = true)
	{
		int len = _tcslen(lpszDir);
		std::vector<TCHAR> vFrom;
		vFrom.resize(len+2,0);
		_tcscpy_s(&vFrom[0],len+2,lpszDir);
		vFrom[len]   = 0;
		vFrom[len+1] = 0;
  
		SHFILEOPSTRUCT fileop;
		fileop.hwnd   = NULL;       // no status display
		fileop.wFunc  = FO_DELETE;  // delete operation
		fileop.pFrom  = &vFrom[0];  // source file name as double null terminated string
		fileop.pTo    = NULL;       // no destination needed
		fileop.fFlags = FOF_NOCONFIRMATION|FOF_SILENT;  // do not prompt the user
  
		if(!noRecycleBin)
		{
			fileop.fFlags |= FOF_ALLOWUNDO;
		}

		fileop.fAnyOperationsAborted = FALSE;
		fileop.lpszProgressTitle     = NULL;
		fileop.hNameMappings         = NULL;

		int ret = SHFileOperation(&fileop);
		vFrom.clear();
		return (ret == 0);
	}

	inline std::string& TrimLeft(std::string& szExpr)
	{
		//�ҵ���һ����tab�Ϳո�("\t ")����ƥ����ַ�λ��
		std::string::size_type iPos1 = szExpr.find_first_not_of("\t ");
		if(iPos1!=std::string::npos && iPos1>0) 
		{
			szExpr.erase(0,iPos1);
		}
		return szExpr;
	}

	inline std::string& TrimRight(std::string& szExpr)
	{
		//�ҵ����һ����tab�Ϳո�("\t ")����ƥ����ַ�λ��
		std::string::size_type iPos2 = szExpr.find_last_not_of("\t ");
		if(iPos2!=std::string::npos) 
		{
			szExpr.erase(iPos2+1);
		}
		return szExpr;
	}

	inline std::string& Trim(std::string& szExpr)
	{
		return TrimRight(TrimLeft(szExpr));
	}

	//delim���κ�һ���ַ������ɷָ��
	inline void SplitString(std::vector<std::string>& vRlt,std::string strOrg,std::string delim)
	{
		vRlt.clear();
		strOrg = Trim(strOrg);
		if(strOrg.size()<1) return;

		if(delim.empty()) 
		{
			vRlt.push_back(strOrg);
			return;
        }
		char* token   = 0;
		char* context = 0;
		token = ::strtok_s(&strOrg[0],&delim[0],&context);
		while(token!=0) 
		{
			vRlt.push_back(token);
			token = ::strtok_s(0,&delim[0],&context);
		}
		return;
	}

	//delim�������ַ������ɷָ��
	inline void HaSplitString(std::vector<std::string>& vRlt,std::string strOrg,std::string delim)
	{
		vRlt.clear();
		strOrg = Trim(strOrg);
		if(strOrg.size()<1) return;

		if(delim.empty()) 
		{
			vRlt.push_back(strOrg);
			return;
        }

		std::string::iterator substart = strOrg.begin(), subend;
		while(true) 
		{
			while(substart!=strOrg.end() && ((*substart==' ') || (*substart=='\t')))
			{
				++substart;
			}
			subend = std::search(substart, strOrg.end(),delim.begin(),delim.end());
			std::string temp(substart, subend);
			temp = TrimRight(temp);
			vRlt.push_back(temp);
			if(subend == strOrg.end()) 
			{
				break;
			}
			substart = subend + delim.size();
		}
		return;
	}

	inline std::wstring gb2w(const std::string& text)
	{
		int len = MultiByteToWideChar(936, 0, text.c_str(), (int)text.length(), 0, 0);
		std::vector<wchar_t> cData;
		cData.resize(len + 1);
		wchar_t * data = &cData[0];
		memset(data, 0, (len + 1) * sizeof(wchar_t));
		MultiByteToWideChar(936, 0, text.c_str(), (int)text.length(), data, len);
		std::wstring ret(data, len);
		cData.clear();
		return ret;
	}

	inline std::string w2utf8(const std::wstring& text)
	{
		int len = WideCharToMultiByte(CP_UTF8, 0, text.c_str(), (int)text.length(), 0, 0, 0, 0);
		std::vector<char> cData;
		cData.resize(len + 1);
		char * data = &cData[0];
		memset(data, 0, len + 1);
		WideCharToMultiByte(CP_UTF8, 0, text.c_str(), (int)text.length(), data, len, 0, 0);
		std::string ret(data, len);
		cData.clear();
		return ret;
	}

	inline void GbkToUCS2(const char* szText,std::vector<wchar_t>& vOutTextW)
	{
		vOutTextW.clear();
		int nOutWideCharNum = ::MultiByteToWideChar(CP_ACP,0,szText,-1,0,0);//���������������Ҫ���ַ��ĸ���
		vOutTextW.resize(nOutWideCharNum+1,0);
		::MultiByteToWideChar(CP_ACP,0,szText,-1,&vOutTextW[0],nOutWideCharNum);
	}

	inline void UTF8ToUCS2(const char* szText,std::vector<wchar_t>& vOutTextW)
	{
		vOutTextW.clear();
		int nOutWideCharNum = ::MultiByteToWideChar(CP_UTF8,0,szText,-1,0,0);//���������������Ҫ���ַ��ĸ���
		vOutTextW.resize(nOutWideCharNum+1,0);
		::MultiByteToWideChar(CP_UTF8,0,szText,-1,&vOutTextW[0],nOutWideCharNum);
	}

	/////////////////////////////////////////////////// UCS2==Unicode
	//int MultiByteToWideChar(
	//  UINT   CodePage,         // code page                 CP_ACP=0 ��ʾ���ر��룬������ϵͳ���ر���=936
	//  DWORD  dwFlags,          // character-type options    dwFlags=0��ʾ�޷�ת�����ַ��������������ַ��滻��������������ʾ
	//  LPCSTR lpMultiByteStr,   // string to map             ������Ҫת�����ַ���
	//  int    cbMultiByte,      // number of bytes in string �����ַ����ĳ��� �ֽ��� ���cbMultiByte=-1��ʾת�����봮�������ַ�������β\0�ַ�
	//  LPWSTR lpWideCharStr,    // wide-character buffer     ת����������ַ��������� 
	//  int    cchWideChar       // size of buffer            ������Ļ�����������Ϊ0�򷵻�ֵΪ�������������Ҫ�ĳ��ȼ����ַ��ĸ���
	//);

	inline void GbkToUTF8(const char* szText,std::vector<char>& vOutText)
	{
		std::vector<wchar_t> vOutTextW;
		GbkToUCS2(szText,vOutTextW);

		int nOutCharNum = ::WideCharToMultiByte(CP_UTF8,0,&vOutTextW[0],-1,0,0,0,0);//�����������������Ҫ���ֽ���
		vOutText.clear();
		vOutText.resize(nOutCharNum+1,0);
		::WideCharToMultiByte(CP_UTF8,0,&vOutTextW[0],-1,&vOutText[0],nOutCharNum,0,0);
		vOutTextW.clear();
	}

	inline void UTF8ToGBK(const char* szText,std::vector<char>& vOutText)
	{
		std::vector<wchar_t> vOutTextW;
		UTF8ToUCS2(szText,vOutTextW);

		int nOutCharNum = ::WideCharToMultiByte(CP_ACP,0,&vOutTextW[0],-1,0,0,0,0);//�����������������Ҫ���ֽ���
		vOutText.clear();
		vOutText.resize(nOutCharNum+1,0);
		::WideCharToMultiByte(CP_ACP,0,&vOutTextW[0],-1,&vOutText[0],nOutCharNum,0,0);
		vOutTextW.clear();
	}
	
	//long pos = file.tellg();  // �õ��ļ�ָ�뵱ǰָ����ļ�λ�á�
	//file.seekg(0,ios::beg);   // ���ļ�ָ�붨λ���ļ���ͷ
	//file.seekg(0,ios::end);   // ���ļ�ָ�붨λ���ļ�ĩβ
	//file.seekg(10,ios::cur);  // ���ļ�ָ��ӵ�ǰλ�����ļ�ĩ�����ƶ�10���ֽ�
	//file.seekg(-10,ios::cur); // ���ļ�ָ��ӵ�ǰλ�����ļ���ʼ�����ƶ�10���ֽ�
	//file.seekg(10,ios::beg);  // ���ļ�ָ�붨λ�����ļ���ͷ10���ֽڵ�λ��	inline std::
	
	inline std::streamoff GetFileSize(std::fstream& ar)
	{
		std::streamoff nOrgPos = ar.tellg();
		ar.seekg(0,std::ios_base::end);
		std::streamoff nSize   = ar.tellg();

		ar.seekg(nOrgPos,std::ios_base::beg);
		return nSize;
	}
	
	inline std::streamoff GetFileSize(std::ifstream& ar)
	{
		std::streamoff nOrgPos = ar.tellg();
		ar.seekg(0,std::ios_base::end);
		std::streamoff nSize   = ar.tellg();

		ar.seekg(nOrgPos,std::ios_base::beg);
		return nSize;
	}
	////////////////////////////////////////////////////////////////////////////////
	// use MFC CStringA
	inline void HaSplitString(std::vector<CStringA>& vRlt,CStringA strOrg,CStringA taken)
	{
		vRlt.clear();
		if(strOrg.IsEmpty() || taken.IsEmpty()) return;

		CStringA left=strOrg,next=strOrg;
		int pos,toklen=taken.GetLength(),orglen;
		while(1)
		{
			pos=next.Find(taken);
			orglen=next.GetLength();
			if(pos>=0) 
			{
				left=next.Left(pos);
				vRlt.push_back(left);
				next=next.Mid(pos+toklen);
			}
			else
			{
				if(!next.IsEmpty()) vRlt.push_back(next);
				break;
			}
		}
	}

	inline void HaSplitString(std::vector<CStringA>& vRlt,CStringA strOrg,char ctaken)
	{
		return HaSplitString(vRlt,strOrg,CStringA(ctaken));
	}

	////////////edit 2008-05-08
	//                                         1   2   3   4   5   6   7   8   9   10
	//�Ӵ�����ͷ��β������ָ���������ֶ� �磺a , b , c , d , e , f , g , h , i , j ,  k
	inline void HaSplitString(CStringA strOrg,CStringA taken,CStringA* strRlt,int nFieldNum)
	{
		std::vector<CStringA> vec;
		HaSplitString(vec,strOrg,taken);
		int num=static_cast<int>(vec.size()),i=0;
		for( i=0;i<=nFieldNum-1;i++)
		{
			strRlt[i]=CStringA("");
		}
		for(i=0;i<=num-1;i++)
		{
			if(i<=nFieldNum-1) strRlt[i]=vec[i];
		}
		vec.clear();
	}

	inline void HaSplitString(CStringA strOrg,char ctaken,CStringA* strRlt,int nFieldNum)
	{
		HaSplitString(strOrg,CStringA(ctaken),strRlt,nFieldNum);
	}


	// 0   1   2   3   4   5   6   7   8   9   10
	// a , b , c , d , e , f , g , h , i , j ,  k
	//���ַ�������","�ָ�ɵ����д��ַ����ν��б��0,1,2...n
	//ȡ��λ��nPos1��λ��nPos2����ַ���������","����
	inline CStringA HaGetSubStrings(CStringA strOrg,CStringA taken,int nPos1,int nPos2)
	{
		if(strOrg.IsEmpty() || taken.IsEmpty()) return CStringA("");
		CStringA tem=strOrg,rlt=CStringA("");
		int pos1,pos2,num=0;
		if((nPos1==nPos2 && nPos1==0) || (nPos1>=0 && nPos2>=0 && nPos1>=nPos2) || nPos1>=tem.GetLength()-1) return CStringA("");
		std::vector<CStringA> vec;
		HaSplitString(vec,strOrg,taken);
		num=static_cast<int>(vec.size());
		if(num<1) 
		{
			vec.clear();
			return strOrg;
		}

		pos1=nPos1;
		pos2=nPos2;
		if(pos1<=0) pos1=0;
		if(pos2>=num || pos2<0) pos2=num-1;
		if(pos1==0 && pos2==num-1) 
		{
			vec.clear();
			return tem;
		}
		if(pos1>=num || pos1>=pos2) 
		{
			vec.clear();
			return CStringA("");
		}
		for(int pos=pos1;pos<=pos2;++pos)
		{
			if(pos==pos1)
			{
				rlt=vec[pos];
			}
			else
			{
				rlt+=taken+vec[pos];
			}
		}
		vec.clear();
		return rlt;
	}

	// 0   1   2   3   4   5   6   7   8   9   10
	// a , b , c , d , e , f , g , h , i , j ,  k
	//���ַ�������","�ָ�ɵ����д��ַ����ν��б��0,1,2...n
	//ȡ��λ��nPos1��λ��nPos2����ַ���������","����
	inline void HaGetSubStrings(CStringA strOrg,CStringA taken,CStringA* strRlt,int nPos1,int nPos2)
	{
		int pos1,pos2,num=0,pos;
		pos1=nPos1;
		pos2=nPos2;
		for(pos=pos1;pos<=pos2;++pos)
		{
			strRlt[pos-pos1]="";
		}

		if(strOrg.IsEmpty() || taken.IsEmpty()) return;
		CStringA tem=strOrg,rlt=CStringA("");
		if((nPos1==nPos2 && nPos1==0) || (nPos1>=0 && nPos2>=0 && nPos1>=nPos2) || nPos1>=tem.GetLength()-1) return;
		std::vector<CStringA> vec;
		HaSplitString(vec,strOrg,taken);
		num=static_cast<int>(vec.size());
		if(num<1) 
		{
			vec.clear();
			return;
		}

		if(pos1<=0) pos1=0;
		if(pos2>=num || pos2<0) pos2=num-1;
		if(pos1>=num || pos1>=pos2) 
		{
			vec.clear();
			return;
		}
		for(int pos=pos1;pos<=pos2;++pos)
		{
			if(pos<=num-1) strRlt[pos-pos1]=vec[pos];
			else strRlt[pos-pos1]="";
		}
		vec.clear();
	}

	inline CStringA GetModulePath()
	{
		HMODULE hModule = ::GetModuleHandleA(NULL);
		char lpFileName[260];
		memset(lpFileName,0,260*sizeof(char));
		::GetModuleFileNameA(hModule,lpFileName,260);
		CStringA dir(lpFileName);
		dir.MakeLower();
		int i=0,len=dir.GetLength();
		if(len<1) return CStringA("");
		int pos=dir.Find("\\debug\\");
		if(pos<0) pos=dir.Find("\\release\\");
		if(pos>0) return dir.Left(pos);

		for(i=len-1;i>0;i--)
		{
			if(dir[i]=='\\') return dir.Left(i);
		}
		return CStringA("");
	}

	inline CStringA GetAnyModulePath()
	{
		char lpFileName[260];
		memset(lpFileName,0,260*sizeof(char));
		::GetModuleFileNameA((HMODULE)&__ImageBase, lpFileName, 260);

		CStringA dir(lpFileName);
		dir.MakeLower();
		int i=0,len=dir.GetLength();
		if(len<1) return CStringA("");
		int pos=dir.Find("\\debug\\");
		if(pos<0) pos=dir.Find("\\release\\");
		if(pos>0) return dir.Left(pos);

		for(i=len-1;i>0;i--)
		{
			if(dir[i]=='\\') return dir.Left(i);
		}
		return CStringA("");
	}

	inline CStringA StripExtension(CStringA szFileName)
	{
		int nPos=szFileName.ReverseFind('.');
		if(nPos<0) return szFileName;
		return szFileName.Left(nPos);
	}

	inline CStringA GetNoPathFileName(CStringA szFileName)
	{
		int nPos=szFileName.ReverseFind('\\');
		if(nPos<0) 
		{
			nPos=szFileName.ReverseFind('/');
		}
		if(nPos<0) return szFileName;
		return szFileName.Mid(nPos+1);
	}

	inline CStringA GetTitle(CStringA szFileName)
	{
		CStringA szNoPathFileName = GetNoPathFileName(szFileName);
		return StripExtension(szNoPathFileName);
	}

	inline DWORD GetStringHashValue(CStringA szExpr)
	{
		return GetStringHashValue(szExpr.GetString());
	}

	inline DWORD GetStringHashValue(const char* szExpr)
	{
		std::string tem(szExpr);
		int nLen=tem.size();
		if(nLen<1) return 0;
		DWORD a=0,b=0,c=0;
		int i=0;

		for(i=0;i<nLen;i++)
		{
			b=szExpr[i];
			c=a+(a<<5);
			a=b^c;
		}
		return (a & 0x7FFFFFFF);
	}

	inline void ConvertDegToDDMMSS(double deg,int& dd,int& mm,double& ss)
	{
		deg=fabs(deg);
		dd=(int)deg;
		mm=(int)((deg-dd)*60);
		ss=((deg-dd)*60-mm)*60;
		if(fabs(ss-60)<1e-7)
		{
			mm = mm+1;
			ss = 0;
		}
	}

	inline void TransLonLat2dms(double lon,double lat,std::string& szBuf)
	{
		double deg,s1,s2;
		int d1,m1,d2,m2;
		deg=fabs(lon);
		d1=(int)deg;
		m1=(int)((deg-d1)*60);
		s1=((deg-d1)*60-m1)*60;
		deg=fabs(lat);
		d2=(int)deg;
		m2=(int)((deg-d2)*60);
		s2=((deg-d2)*60-m2)*60;
		if(int(szBuf.size())<80)
		{
			szBuf.resize(80);
		}
		int nSize = int(szBuf.size());
		memset(&szBuf[0],0,nSize);
		sprintf_s(&szBuf[0],200,"%03d,%02d,%02.6f,%s,%02d,%02d,%02.6f,%s\n",d1,m1,s1,lon<0?"W":"E",d2,m2,s2,lat<0?"S":"N");
	}

	//�жϸ������ַ����Ƿ���0--9�������
	inline bool IsDigitString(CStringA str)
	{
		if(str.IsEmpty()) return true;
		CStringA tem=CStringA(str);
		int len=tem.GetLength();
		for(int i=0;i<len;i++)
		{
			int c=int(tem.GetAt(i));
			if(!std::isdigit(c)) return false;
		}
		return true;		
	}

	//�жϸ������ַ����Ƿ�Ϊ������(��������ѧ������������)
	inline bool IsFloatString(CStringA str)
	{
		str.TrimLeft();
		str.TrimLeft();
		if(str.IsEmpty()) return true;
		int len=str.GetLength();
		CStringA str2;
		if(str[0]=='-' || str[0]=='+') str2=str.Right(len-1);
		else str2=str;
		str2.TrimLeft();
		str2.TrimLeft();
		if(str2.IsEmpty()) return false;
		int index=str2.Find(CStringA("."));
		if(index>=0) str2.SetAt(index,'1');
		return IsDigitString(str2);	
	}
	
	inline bool ScientificStr2(CStringA& str,CStringA Token,double& data)
	{
		data=0;
		int index=str.Find(Token);
		int len=Token.GetLength();
		if(index<1 || len<1) return false;
		if(str.GetLength()-1<index+len) return false;
		CStringA str1,str2,str0;
		str1=str.Left(index);
		str2=str.Mid(index+len);
		str0="";
		if(str1[0]=='+' || str1[0]=='-') {str0=str1[0];str1=str1.Mid(1);}
		if(!IsDigitString(str1) || !IsDigitString(str2)) return false;
		int data1=atoi(CStringA(str1));
		if(str0=="-") data1=-data1;
		int data2=atoi(CStringA(str2));
		if(Token[len-1]=='-') data2=-data2;
		data=data1*pow(10.0,data2);
		return true;
	}

	//�жϸ������ַ����Ƿ�Ϊ������(������ѧ������������)
	inline bool IsFloatOrScientificString(CStringA str)
	{
		if(str.IsEmpty()) return true;
		CStringA str2;
		str2=str;
		double data=0;
		BOOL flg=false;
		if(str2.Find(CStringA("E+"))>=1)
		{
			if(!ScientificStr2(str2,CStringA("E+"),data)) return false;
			else flg=true;
		}
		else if(str2.Find(CStringA("E-"))>=1)
		{
			if(!ScientificStr2(str2,CStringA("E-"),data)) return false;
			else flg=true;
		}
		else if(str2.Find(CStringA("e+"))>=1)
		{
			if(!ScientificStr2(str2,CStringA("e+"),data)) return false;
			else flg=true;
		}
		else if(str2.Find(CStringA("e-"))>=1)
		{
			if(!ScientificStr2(str2,CStringA("e-"),data)) return false;
			else flg=true;
		}
		else if(str2.Find(CStringA("e"))>=1)
		{
			if(!ScientificStr2(str2,CStringA("e"),data)) return false;
			else flg=true;
		}
		else if(str2.Find(CStringA("E"))>=1)
		{
			if(!ScientificStr2(str2,CStringA(CStringA("E")),data)) return false;
			else flg=true;
		}
		if(!flg && !IsFloatString(str2)) return false;
		return true;
	}

	//�жϸ������ַ����Ƿ���0--9�е����ֺͿո����
	inline bool IsDigitSpaceString(CStringA str)
	{
		if(str.IsEmpty()) return true;
		CStringA tem=CStringA(str);
		int len=tem.GetLength();
		for(int i=0;i<len;i++)
		{
			int c=int(tem.GetAt(i));
			if(!std::isdigit(c) && c!=' ') return false;
		}
		return true;
	}

	//�жϸ������ַ����Ƿ���a--z �� A--Z �е�Ӣ���ַ����
	inline bool IsEnglishString(CStringA str)
	{
		if(str.IsEmpty()) return true;
		int len=str.GetLength();
		for(int i=0;i<len;i++)
		{
			int c=int(str.GetAt(i));
			if(!std::isalpha(c)) return false;
		}
		return true;
	}

	///////////////////////////////
	inline std::string char2hex( char dec )
	{
		char dig1 = (dec&0xF0)>>4;
		char dig2 = (dec&0x0F);
		if ( 0<= dig1 && dig1<= 9) dig1+=48;    //0,48inascii
		if (10<= dig1 && dig1<=15) dig1+=97-10; //a,97inascii
		if ( 0<= dig2 && dig2<= 9) dig2+=48;
		if (10<= dig2 && dig2<=15) dig2+=97-10;

		std::string r;
		r.append( &dig1, 1);
		r.append( &dig2, 1);
		return r;
	}

	//based on javascript encodeURIComponent()
	inline std::string UrlEncode(const std::string &cUTF8)
	{
		std::string escaped="";
		int max = cUTF8.length();
		for(int i=0; i<max; i++)
		{
			if ( (48 <= cUTF8[i] && cUTF8[i] <= 57) ||//0-9
				 (65 <= cUTF8[i] && cUTF8[i] <= 90) ||//abc...xyz
				 (97 <= cUTF8[i] && cUTF8[i] <= 122) || //ABC...XYZ
				 (cUTF8[i]=='~' || cUTF8[i]=='!' || cUTF8[i]=='*' || cUTF8[i]=='(' || cUTF8[i]==')' || cUTF8[i]=='\'')
			)
			{
				escaped.append( &cUTF8[i], 1);
			}
			else
			{
				escaped.append("%");
				escaped.append( char2hex(cUTF8[i]));//converts char 255 to string "ff"
			}
		}
		return escaped;
	}

	inline std::string GetMyComputerName()
	{
		TCHAR  infoBuf[50];
		char   buf[50*2];
		DWORD  bufsize = 50;

		std::string szRlt="";
		memset(&infoBuf[0],0,sizeof(TCHAR)*bufsize);
		memset(&buf[0],0,sizeof(char)*bufsize*2+1);
		if(::GetComputerName(infoBuf, &bufsize))
		{
			size_t nSize;
			wcstombs_s(&nSize,buf,bufsize*2,infoBuf,bufsize*2);
			szRlt = std::string(buf);
		}
		return szRlt;
	}
	// Use wcstombs_s and mbstowcs_s   
	inline std::string ws2s(std::wstring ws)  
	{  
		const wchar_t* Source = ws.c_str();  
		size_t size = 2 * ws.size() + 1; 
		std::vector<char> Dest;
		Dest.resize(size,0);
		size_t len = 0;  
		wcstombs_s(&len,&Dest[0],size, Source, size-1);  
		std::string result = &Dest[0];    
		return result;  
	}  
  
	inline std::wstring s2ws(std::string s)  
	{  
		size_t size  = s.size() + 1;  
		size_t size1 = s.size();  
		std::vector<wchar_t> Dest;
		Dest.resize(size,0);

		size_t len = 0;  
		mbstowcs_s(&len,&Dest[0],size, s.c_str(),s.size());  

		std::wstring result = &Dest[0];  
  
		return result;  
	}  
	
	inline int String2Integer(const std::string& szValue)
	{
		int nRlt = 0;
		std::istringstream iStream(szValue);
		iStream>>nRlt;
		if(!iStream) nRlt = 0;
		return nRlt;
	}
	inline double String2Float(const std::string& szValue)
	{
		double fRlt = 0;
		std::istringstream iStream(szValue);
		iStream>>fRlt;
		if(!iStream) fRlt = 0;
		return fRlt;
	}

	inline std::string Integer2String(const int& nValue)
	{
		std::string szRlt = "";
		std::ostringstream oStream;
		oStream<<nValue;
		return oStream.str();
	}
	
	//mbedit 20130609 add f
	inline float CString2Float(CString s)
	{
		return _tstof(s);
	}
}

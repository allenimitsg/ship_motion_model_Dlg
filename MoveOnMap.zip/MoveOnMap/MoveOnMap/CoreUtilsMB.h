#pragma once
#include <vector>
#include <functional>
#include <string>
#include <algorithm>
#include <iterator>
#include <cctype>
#include <fstream>
#include <sstream>

#include "afxsock.h"
#include "CoreUtils.h"


//�޶���¼
//2012-02-29 ����SplitString ����delim���κ�һ���ַ������ɷָ��;ԭHaSplitString�����в���delim�������ַ������ɷָ��


// Get DLL instance
EXTERN_C IMAGE_DOS_HEADER __ImageBase;
namespace mb
{
	//mbedit 20130609 add f
	inline float CString2Float(CString s)
	{
		return _tstof(s);
	}
	//mb edit 20130927
#ifndef CONVERT_TO_STRING  
#define CONVERT_TO_STRING  
	template <class T>  
	std::string ConvertToString(T value)   
	{ 
		int prec = std::numeric_limits<T>::digits10;  
		std::stringstream ss;  
		ss.str("");  
		ss.precision(prec);  
		ss << value;  
		return ss.str();  
	}  
#endif


	inline std::vector<std::string> File2VecStr(std::string FilePath)
	{
		std::ifstream sReadData(FilePath,std::fstream::binary);
		std::vector<BYTE> vReadData;
		std::streamoff cn = sgy::GetFileSize(sReadData);
		vReadData.resize(cn++);
		sReadData.read((char*)&(vReadData[0]),cn++);
		std::string str("00");
		str[0] = 13;str[1] = 10;

		std::vector<std::string> vOnePoint;
		sgy::SplitString(vOnePoint, (char*)&vReadData[0],str);
		return vOnePoint;
	}

}


// MoveOnMapDlg.h : ͷ�ļ�
//

#pragma once
#include "ShipModel.h"
#include <vector>
#include "afxcmn.h"
#include "RoundSliderCtrl.h"
#include "CoreUtilsMB.h"
// CMoveOnMapDlg �Ի���
class CMoveOnMapDlg : public CDialogEx
{
// ����
public:
	CMoveOnMapDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_MOVEONMAP_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	ShipModel m_RTShipMod;
	CStatic m_MapArea;
	void DrawShip(void);
	afx_msg void OnBnClickedMAction();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	CRoundSliderCtrl m_RSPanel;
	int m_RSPanelVal;
	afx_msg void OnNMCustomdrawMPanel(NMHDR *pNMHDR, LRESULT *pResult);
};
